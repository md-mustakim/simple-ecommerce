<?php
class categoryModel extends CI_Model{

}